package media;

public class Book extends MediaItem{

	public Book(String name, String genre, int year, int length, String type, String location) {
		super(name, genre, year, length, type, location);
		// TODO Auto-generated constructor stub
	}

}
