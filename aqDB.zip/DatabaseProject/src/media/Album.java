package media;

public class Album extends MediaItem {

	public Album(String name, String genre, int year, int length, String type, String location) {
		super(name, genre, year, length, type, location);
	}
	
}
