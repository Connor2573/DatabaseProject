import java.util.HashSet;
import java.util.Set;

import ordering.Order;

import media.*;

public class OrderCollection {
	
	private Set<Order> orders;

	
	
	public OrderCollection() {
		orders = new HashSet<Order>();
	}
	
	

	
}
